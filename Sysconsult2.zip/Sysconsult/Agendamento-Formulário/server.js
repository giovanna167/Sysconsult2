import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json());

app.post('/api/register', async (req, res) => {
  try {
    const apiResponse = await fetch('https://gestaoapi.teclaconsultoria.com.br/api/Sysconsult/UserRegister', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': req.headers['authorization'] || 'Bearer G7k2P9x4M1q8R5zC'
      },
      body: JSON.stringify(req.body)
    });

    const data = await apiResponse.json();
    return res.status(apiResponse.status).json(data);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

app.listen(3000, () => console.log('Proxy rodando em http://localhost:3000'));